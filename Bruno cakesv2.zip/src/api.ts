// Configuração da API para Bruno Cakes
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? 'https://api.brunocakes.com.br' 
  : 'http://localhost:8000/api';

// Configuração da loja Bruno Cakes
export const STORE_CONFIG = {
  name: 'Bruno Cakes',
  slogan: 'Aqui não é fatia nem pedaço, aqui é tora!',
  address: 'Rua das Tortas, 123 - Centro, São Paulo - SP',
  phone: '(11) 99999-9999',
  email: 'contato@brunocakes.com.br',
  pixKey: 'contato@brunocakes.com.br',
  workingHours: 'Segunda à Sábado: 8h às 18h | Domingo: 9h às 15h',
  instagram: '@brunocakes_oficial',
  whatsapp: '5511999999999'
};

// Endpoints da API conforme Laravel routes
export const API_ENDPOINTS = {
  // Auth (apenas admin)
  auth: {
    adminLogin: `${API_BASE_URL}/login`,
    logout: `${API_BASE_URL}/logout`,
    me: `${API_BASE_URL}/me`
  },
  
  // Clientes (registro público e gerenciamento admin)
  clients: {
    register: `${API_BASE_URL}/register-cliente`, // registro público
    list: `${API_BASE_URL}/clients`, // admin only
    show: (id: string) => `${API_BASE_URL}/clients/${id}`, // admin only
    update: (id: string) => `${API_BASE_URL}/clients/${id}`, // admin only
    delete: (id: string) => `${API_BASE_URL}/clients/${id}` // admin only
  },
  
  // Produtos (públicos para visualização)
  products: {
    list: `${API_BASE_URL}/products`, // público
    show: (id: string) => `${API_BASE_URL}/products/${id}`, // público
    create: `${API_BASE_URL}/products`, // admin only
    update: (id: string) => `${API_BASE_URL}/products/${id}`, // admin only
    delete: (id: string) => `${API_BASE_URL}/products/${id}` // admin only
  },
  
  // Pedidos
  orders: {
    create: `${API_BASE_URL}/orders`, // público (cliente)
    list: `${API_BASE_URL}/orders`, // admin only
    show: (id: string) => `${API_BASE_URL}/orders/${id}`, // admin only
    update: (id: string) => `${API_BASE_URL}/orders/${id}`, // admin only
    delete: (id: string) => `${API_BASE_URL}/orders/${id}`, // admin only
    myOrders: `${API_BASE_URL}/orders` // cliente autenticado
  },
  
  // Pagamentos
  payments: {
    create: `${API_BASE_URL}/payments`, // público (cliente)
    list: `${API_BASE_URL}/payments`, // admin only
    show: (id: string) => `${API_BASE_URL}/payments/${id}`, // admin only
    myPayments: `${API_BASE_URL}/payments` // cliente autenticado
  },
  
  // Entregas (admin only)
  deliveries: {
    list: `${API_BASE_URL}/deliveries`,
    create: `${API_BASE_URL}/deliveries`,
    show: (id: string) => `${API_BASE_URL}/deliveries/${id}`,
    update: (id: string) => `${API_BASE_URL}/deliveries/${id}`,
    delete: (id: string) => `${API_BASE_URL}/deliveries/${id}`
  }
};

// Headers padrão
const getAuthHeaders = () => {
  const token = localStorage.getItem('admin_token');
  return {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` })
  };
};

// Função utilitária para chamadas da API
export const apiRequest = async (url: string, options: RequestInit = {}) => {
  const defaultOptions: RequestInit = {
    headers: {
      ...getAuthHeaders(),
      ...options.headers
    },
    ...options
  };

  try {
    const response = await fetch(url, defaultOptions);
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// Funções específicas da API
export const api = {
  // Auth (Admin apenas)
  adminLogin: (email: string, password: string) =>
    apiRequest(API_ENDPOINTS.auth.adminLogin, {
      method: 'POST',
      body: JSON.stringify({ email, password })
    }),
    
  logout: () =>
    apiRequest(API_ENDPOINTS.auth.logout, { method: 'POST' }),
    
  getMe: () =>
    apiRequest(API_ENDPOINTS.auth.me),
    
  // Produtos (público)
  getProducts: () => 
    apiRequest(API_ENDPOINTS.products.list),
    
  getProduct: (id: string) =>
    apiRequest(API_ENDPOINTS.products.show(id)),
    
  // Admin - Produtos
  createProduct: (product: any) =>
    apiRequest(API_ENDPOINTS.products.create, {
      method: 'POST',
      body: JSON.stringify(product)
    }),
    
  updateProduct: (id: string, product: any) =>
    apiRequest(API_ENDPOINTS.products.update(id), {
      method: 'PUT',
      body: JSON.stringify(product)
    }),
    
  deleteProduct: (id: string) =>
    apiRequest(API_ENDPOINTS.products.delete(id), { 
      method: 'DELETE' 
    }),
    
  // Clientes
  registerClient: (clientData: any) =>
    apiRequest(API_ENDPOINTS.clients.register, {
      method: 'POST',
      body: JSON.stringify(clientData)
    }),
    
  // Admin - Clientes
  getClients: () =>
    apiRequest(API_ENDPOINTS.clients.list),
    
  getClient: (id: string) =>
    apiRequest(API_ENDPOINTS.clients.show(id)),
    
  updateClient: (id: string, clientData: any) =>
    apiRequest(API_ENDPOINTS.clients.update(id), {
      method: 'PUT',
      body: JSON.stringify(clientData)
    }),
    
  deleteClient: (id: string) =>
    apiRequest(API_ENDPOINTS.clients.delete(id), { 
      method: 'DELETE' 
    }),
    
  // Pedidos
  createOrder: (orderData: any) =>
    apiRequest(API_ENDPOINTS.orders.create, {
      method: 'POST',
      body: JSON.stringify(orderData)
    }),
    
  // Admin - Pedidos
  getOrders: () =>
    apiRequest(API_ENDPOINTS.orders.list),
    
  getOrder: (id: string) =>
    apiRequest(API_ENDPOINTS.orders.show(id)),
    
  updateOrder: (id: string, orderData: any) =>
    apiRequest(API_ENDPOINTS.orders.update(id), {
      method: 'PUT',
      body: JSON.stringify(orderData)
    }),
    
  // Pagamentos
  createPayment: (paymentData: any) =>
    apiRequest(API_ENDPOINTS.payments.create, {
      method: 'POST',
      body: JSON.stringify(paymentData)
    }),
    
  // Admin - Pagamentos
  getPayments: () =>
    apiRequest(API_ENDPOINTS.payments.list),
    
  getPayment: (id: string) =>
    apiRequest(API_ENDPOINTS.payments.show(id)),
    
  // Admin - Entregas
  getDeliveries: () =>
    apiRequest(API_ENDPOINTS.deliveries.list),
    
  createDelivery: (deliveryData: any) =>
    apiRequest(API_ENDPOINTS.deliveries.create, {
      method: 'POST',
      body: JSON.stringify(deliveryData)
    }),
    
  updateDelivery: (id: string, deliveryData: any) =>
    apiRequest(API_ENDPOINTS.deliveries.update(id), {
      method: 'PUT',
      body: JSON.stringify(deliveryData)
    })
};

export default api;